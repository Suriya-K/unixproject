void emit(char *msg, double v);
